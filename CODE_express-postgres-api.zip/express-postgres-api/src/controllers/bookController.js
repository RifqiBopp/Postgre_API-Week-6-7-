const { Book, User } = require('../../models');

module.exports = {
  async getAllBooks(req, res) {
    try {
      const books = await Book.findAll({ include: User }); // ikut tampilkan user-nya
      res.json(books);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  },

  async getBookById(req, res) {
    try {
      const book = await Book.findByPk(req.params.id, { include: User });
      if (!book) return res.status(404).json({ message: 'Book not found' });
      res.json(book);
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  },

  async createBook(req, res) {
    try {
      const { title, author, userId } = req.body;
      const book = await Book.create({ title, author, userId });
      res.status(201).json(book);
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  },

  async updateBook(req, res) {
    try {
      const [updated] = await Book.update(req.body, {
        where: { id: req.params.id }
      });
      if (!updated) return res.status(404).json({ message: 'Book not found' });

      const updatedBook = await Book.findByPk(req.params.id);
      res.json(updatedBook);
    } catch (err) {
      res.status(400).json({ message: err.message });
    }
  },

  async deleteBook(req, res) {
    try {
      const deleted = await Book.destroy({
        where: { id: req.params.id }
      });
      if (!deleted) return res.status(404).json({ message: 'Book not found' });

      res.json({ message: 'Book deleted' });
    } catch (err) {
      res.status(500).json({ message: err.message });
    }
  }
};
