const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const { userValidationRules, validate } = require('../middleware/validateUser');

router.get('/users', userController.getAllUsers);
router.post('/', userValidationRules, validate, userController.createUser);
router.get('/:id', userController.getUserById);
router.put('/:id', userController.updateUser);
router.delete('/:id', userController.deleteUser);

module.exports = router; // <--- pastikan baris ini ada
