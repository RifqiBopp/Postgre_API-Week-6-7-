'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('user', [
      {
        name: 'Rifqi',
        email: 'rifqi@example.com',
        createAt: new Date(),
        updateAt: new Date()
      },
      {
        name: 'Apriansyah',
        email: 'apriansyah@example.com',
        createAt: new Date(),
        updateAt: new Date()
      }
    ], {});

  },

  async down (queryInterface, Sequelize) {

    await queryInterface.bulkDelete('user', null, {});
  }
};
